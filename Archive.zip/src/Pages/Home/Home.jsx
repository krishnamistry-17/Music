import React from "react";
import Albums from "../Albums/Albums";

const Home = () => {
  return (
    <div className="">
      <div>
        <Albums />
      </div>
    </div>
  );
};

export default Home;
{
  /*Mp3 audio file */
}
